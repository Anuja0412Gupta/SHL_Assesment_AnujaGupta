from fastapi import FastAPI
from pydantic import BaseModel

from rag_pipeline import run_pipeline


app = FastAPI(title="SHL Assessment Recommender")


class RecommendRequest(BaseModel):
    query: str


@app.get("/health")
def health():
    """
    Basic health check endpoint.
    """
    return {"status": "ok"}


@app.post("/recommend")
def recommend(payload: RecommendRequest):
    """
    Recommend SHL assessments based on a natural-language query.
    """
    rewritten_query, docs, explanation = run_pipeline(payload.query)

    assessments = []
    for d in docs:
        meta = dict(d.metadata) if d.metadata else {}
        meta["page_content"] = d.page_content
        assessments.append(meta)

    return {
        "rewritten_query": rewritten_query,
        "assessments": assessments,
        "explanation": explanation,
    }


