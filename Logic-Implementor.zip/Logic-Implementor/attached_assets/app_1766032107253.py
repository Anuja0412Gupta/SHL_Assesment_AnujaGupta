# app.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse


from rag_pipeline import run_pipeline
templates = Jinja2Templates(directory="templates")


app = FastAPI(title="Recommendation API")

class RecommendRequest(BaseModel):
    query: str

class AssessmentResponse(BaseModel):
    name: str
    url: str
    test_type: str
    remote_support: str
    adaptive_support: str

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/recommend")
def recommend(req: RecommendRequest):
    if not req.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    rewritten, docs, explanation = run_pipeline(req.query)

    results = []
    for d in docs[:10]:
        results.append({
            "name": d.metadata["name"],
            "url": d.metadata["url"],
            "test_type": d.metadata["test_type"],
            "remote_support": d.metadata["remote_support"],
            "adaptive_support": d.metadata["adaptive_support"],
        })

    return {
        "query": req.query,
        "rewritten_query": rewritten,
        "recommended_assessments": results,
        "explanation": explanation
    }

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request}
    )

@app.post("/ui-recommend", response_class=HTMLResponse)
def ui_recommend(request: Request, query: str = Form(...)):
    rewritten, docs, explanation = run_pipeline(query)

    results = []
    for d in docs[:10]:
        results.append({
            "name": d.metadata["name"],
            "url": d.metadata["url"],
            "test_type": d.metadata["test_type"],
            "remote_support": d.metadata["remote_support"],
            "adaptive_support": d.metadata["adaptive_support"]
        })

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "results": results,
            "explanation": explanation
        }
    )


