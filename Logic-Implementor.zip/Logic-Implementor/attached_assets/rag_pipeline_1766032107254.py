# rag_pipeline.py
"""
RAG pipeline for SHL Assessment Recommendation
Converted from Colab notebook
"""

import os
import json
import re
import pandas as pd
import google.generativeai as genai

from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.runnables import RunnableSequence
from langchain_core.prompts import PromptTemplate

# --------------------
# Load dataset
# --------------------
# The CSV is expected to be in the project root as: shl_individual_test_solutions_final.csv
df = pd.read_csv("shl_individual_test_solutions_final.csv")

# --------------------
# Build documents
# --------------------
documents = []
for _, row in df.iterrows():
    doc = f"""
Assessment Name: {row['name']}
Test Type: {row['test_type']}
Remote Testing Support: {row['remote_support']}
Adaptive / IRT Support: {row['adaptive_support']}
"""
    documents.append(doc.strip())

lc_documents = []
for i, doc in enumerate(documents):
    lc_documents.append(
        Document(
            page_content=doc,
            metadata={
                "name": df.iloc[i]["name"],
                "url": df.iloc[i]["url"],
                "test_type": df.iloc[i]["test_type"],
                "remote_support": df.iloc[i]["remote_support"],
                "adaptive_support": df.iloc[i]["adaptive_support"]
            }
        )
    )

# --------------------
# Vector Store
# --------------------
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

vectorstore = FAISS.from_documents(lc_documents, embeddings)
retriever = vectorstore.as_retriever(search_kwargs={"k": 10})

# --------------------
# Gemini setup
# --------------------
# Expect the API key in the environment variable: GOOGLE_API_KEY
api_key = os.getenv("AIzaSyDPy_fcvgEyq6PN9ADmE7HodUazWuBIG6I")
if not api_key:
    raise RuntimeError(
        "GOOGLE_API_KEY environment variable is not set. "
        "Please set it to your Google Gemini API key before running the service."
    )

genai.configure(api_key=api_key)
model = genai.GenerativeModel("gemini-2.5-flash")

QUERY_PROMPT = """
Extract the following information from the user query and return ONLY valid JSON.

Required fields:
- technical_skills: list of strings
- soft_skills: list of strings
- intent: short string

User query:
{query}

Return ONLY JSON. No extra text.
"""

def rewrite_query_with_gemini(user_query):
    try:
        prompt = QUERY_PROMPT.format(query=user_query)
        response = model.generate_content(
            prompt,
            generation_config={"temperature": 0.0, "max_output_tokens": 200}
        )
        raw_text = response.text.strip()
        cleaned = re.sub(r"```json|```", "", raw_text).strip()

        start = cleaned.find("{")
        end = cleaned.rfind("}") + 1
        parsed = json.loads(cleaned[start:end])

        tech = " ".join(parsed.get("technical_skills", []))
        soft = " ".join(parsed.get("soft_skills", []))
        intent = parsed.get("intent", "")

        retrieval_query = f"{tech} {soft} {intent}".strip()
        return retrieval_query if retrieval_query else user_query
    except Exception:
        return user_query

# --------------------
# Retrieval
# --------------------
def retrieve_with_langchain(query):
    return retriever.invoke(query)

# --------------------
# Recommendation reasoning
# --------------------
RECOMMENDATION_PROMPT = PromptTemplate(
    input_variables=["query", "assessments"],
    template="""
You are an expert hiring assessment consultant.

User query:
{query}

Test Type Legend:
A = Ability & Aptitude
B = Biodata & Situational Judgement
C = Competencies
D = Development & 360
E = Assessment Exercises
K = Knowledge & Skills
P = Personality & Behavior
S = Simulations

Retrieved assessments:
{assessments}

Task:
- Select between 5 and 10 assessments
- Balance technical and behavioral coverage
- Provide short justification

Return bullet points.
"""
)

llm_reasoning = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.2
)

recommend_chain = RunnableSequence(
    RECOMMENDATION_PROMPT,
    llm_reasoning
)

def format_docs_for_reasoning(docs):
    return "\n".join([
        f"- {d.metadata['name']} | Type: {d.metadata['test_type']} | Remote: {d.metadata['remote_support']} | Adaptive: {d.metadata['adaptive_support']}"
        for d in docs
    ])

def recommendation_reasoning(user_query, docs):
    response = recommend_chain.invoke({
        "query": user_query,
        "assessments": format_docs_for_reasoning(docs)
    })
    return response.content

# --------------------
# Final pipeline
# --------------------
def run_pipeline(user_query):
    rewritten = rewrite_query_with_gemini(user_query)
    docs = retrieve_with_langchain(rewritten)
    explanation = recommendation_reasoning(user_query, docs)
    return rewritten, docs, explanation
