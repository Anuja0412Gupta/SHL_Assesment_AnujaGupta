import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Check, X, Monitor, Brain, Users, Code, LineChart } from "lucide-react";
import { Assessment } from "@/lib/shl-data";
import { motion } from "framer-motion";

interface ResultsTableProps {
  assessments: Assessment[];
}

function getTestTypeIcon(type: string) {
  if (type.includes("K")) return <Code className="h-4 w-4 text-blue-500" />;
  if (type.includes("P") || type.includes("B")) return <Users className="h-4 w-4 text-purple-500" />;
  if (type.includes("A")) return <Brain className="h-4 w-4 text-amber-500" />;
  return <LineChart className="h-4 w-4 text-slate-500" />;
}

export function ResultsTable({ assessments }: ResultsTableProps) {
  return (
    <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
      <Table>
        <TableHeader className="bg-slate-50/50">
          <TableRow>
            <TableHead className="w-[300px]">Assessment Name</TableHead>
            <TableHead>Test Type</TableHead>
            <TableHead className="text-center">Remote Support</TableHead>
            <TableHead className="text-center">Adaptive</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {assessments.map((item, index) => (
            <motion.tr 
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="group hover:bg-slate-50 transition-colors"
            >
              <TableCell className="font-medium text-foreground">
                {item.name}
              </TableCell>
              <TableCell>
                <div className="flex flex-wrap gap-1">
                  {item.test_type.split(',').map((type) => (
                    <Badge variant="secondary" key={type} className="flex items-center gap-1.5 px-2 py-0.5 border-slate-200">
                      {getTestTypeIcon(type)}
                      <span>Type {type.trim()}</span>
                    </Badge>
                  ))}
                </div>
              </TableCell>
              <TableCell className="text-center">
                {item.remote_support === "Yes" ? (
                  <div className="flex justify-center">
                    <div className="h-6 w-6 rounded-full bg-green-100 flex items-center justify-center">
                      <Check className="h-3 w-3 text-green-600" />
                    </div>
                  </div>
                ) : (
                  <div className="flex justify-center">
                     <span className="text-slate-300">-</span>
                  </div>
                )}
              </TableCell>
              <TableCell className="text-center">
                {item.adaptive_support === "Yes" ? (
                  <div className="flex justify-center">
                    <Badge variant="outline" className="border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100">
                      Adaptive
                    </Badge>
                  </div>
                ) : (
                  <span className="text-muted-foreground text-xs">Standard</span>
                )}
              </TableCell>
              <TableCell className="text-right">
                <a 
                  href={item.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline hover:text-primary/80"
                >
                  View Catalog
                  <ExternalLink className="h-3 w-3" />
                </a>
              </TableCell>
            </motion.tr>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
