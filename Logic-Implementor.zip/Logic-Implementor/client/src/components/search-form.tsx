import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Search, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

interface SearchFormProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

export function SearchForm({ onSearch, isLoading }: SearchFormProps) {
  const [query, setQuery] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-3xl mx-auto"
    >
      <form onSubmit={handleSubmit} className="relative group">
        <div className="absolute inset-0 bg-primary/20 blur-xl rounded-2xl group-hover:bg-primary/30 transition-all duration-500 opacity-50" />
        <div className="relative bg-white rounded-2xl shadow-xl border overflow-hidden p-2 flex flex-col gap-2">
          <Textarea
            placeholder="Describe the role you are hiring for (e.g., 'Senior Java Developer who can lead a team')..."
            className="border-none shadow-none resize-none min-h-[100px] text-lg p-4 focus-visible:ring-0"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          <div className="flex justify-between items-center px-2 pb-1">
            <span className="text-xs text-muted-foreground ml-2">Press Enter to search</span>
            <Button 
              type="submit" 
              disabled={isLoading || !query.trim()}
              className="rounded-xl px-6 h-10 bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20 transition-all active:scale-95"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" />
                  Find Assessments
                </>
              )}
            </Button>
          </div>
        </div>
      </form>
    </motion.div>
  );
}
