import { Link } from "wouter";

export function Nav() {
  return (
    <header className="border-b bg-white sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center gap-2">
            <div className="bg-primary h-8 w-8 rounded flex items-center justify-center text-white font-bold font-serif">S</div>
            <span className="font-serif font-bold text-xl tracking-tight text-primary">SHL Recommender</span>
          </a>
        </Link>
        <nav className="flex items-center gap-6 text-sm font-medium text-muted-foreground">
          <Link href="/"><a className="hover:text-primary transition-colors">Search</a></Link>
          <a href="#" className="hover:text-primary transition-colors">Catalog</a>
          <a href="#" className="hover:text-primary transition-colors">About</a>
        </nav>
      </div>
    </header>
  );
}
