// Remove mock data usage and use real API
// import { shlAssessments, Assessment } from "./shl-data"; 

export interface Assessment {
  name: string;
  url: string;
  remote_support: string;
  adaptive_support: string;
  test_type: string;
}

export interface RecommendationResponse {
  query: string;
  rewritten_query: string;
  recommended_assessments: Assessment[];
  explanation: string;
}

export async function getRecommendations(query: string): Promise<RecommendationResponse> {
  const response = await fetch("/recommend", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query }),
  });

  if (!response.ok) {
    throw new Error("Failed to fetch recommendations");
  }

  return response.json();
}
