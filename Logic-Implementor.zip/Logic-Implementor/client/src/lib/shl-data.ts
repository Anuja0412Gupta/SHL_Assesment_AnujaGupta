export interface Assessment {
  name: string;
  url: string;
  remote_support: string;
  adaptive_support: string;
  test_type: string;
}

export const shlAssessments: Assessment[] = [
  {
    name: "Global Skills Development Report",
    url: "https://www.shl.com/products/product-catalog/view/global-skills-development-report/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "A,E,B,C,D,P"
  },
  {
    name: ".NET Framework 4.5",
    url: "https://www.shl.com/products/product-catalog/view/net-framework-4-5/",
    remote_support: "Yes",
    adaptive_support: "Yes",
    test_type: "K"
  },
  {
    name: ".NET MVC (New)",
    url: "https://www.shl.com/products/product-catalog/view/net-mvc-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Accounts Payable (New)",
    url: "https://www.shl.com/products/product-catalog/view/accounts-payable-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Accounts Payable Simulation (New)",
    url: "https://www.shl.com/products/product-catalog/view/accounts-payable-simulation-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "S"
  },
  {
    name: "Adobe Photoshop CC",
    url: "https://www.shl.com/products/product-catalog/view/adobe-photoshop-cc/",
    remote_support: "Yes",
    adaptive_support: "Yes",
    test_type: "K"
  },
  {
    name: "Agile Software Development",
    url: "https://www.shl.com/products/product-catalog/view/agile-software-development/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "AI Skills",
    url: "https://www.shl.com/products/product-catalog/view/ai-skills/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "P"
  },
  {
    name: "Amazon Web Services (AWS) Development (New)",
    url: "https://www.shl.com/products/product-catalog/view/amazon-web-services-aws-development-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Android Development (New)",
    url: "https://www.shl.com/products/product-catalog/view/android-development-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Angular 6 (New)",
    url: "https://www.shl.com/products/product-catalog/view/angular-6-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Apache Hadoop (New)",
    url: "https://www.shl.com/products/product-catalog/view/apache-hadoop-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "ASP.NET 4.5",
    url: "https://www.shl.com/products/product-catalog/view/asp-net-4-5/",
    remote_support: "Yes",
    adaptive_support: "Yes",
    test_type: "K"
  },
  {
    name: "Automata - SQL (New)",
    url: "https://www.shl.com/products/product-catalog/view/automata-sql-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "S"
  },
  {
    name: "Automata Data Science (New)",
    url: "https://www.shl.com/products/product-catalog/view/automata-data-science-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "S"
  },
  {
    name: "Basic Computer Literacy (Windows 10) (New)",
    url: "https://www.shl.com/products/product-catalog/view/basic-computer-literacy-windows-10-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "S,K"
  },
  {
    name: "Business Communication (adaptive)",
    url: "https://www.shl.com/products/product-catalog/view/business-communication-adaptive/",
    remote_support: "Yes",
    adaptive_support: "Yes",
    test_type: "K"
  },
  {
    name: "C# Programming (New)",
    url: "https://www.shl.com/products/product-catalog/view/c-programming-new-4039/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Cloud Computing (New)",
    url: "https://www.shl.com/products/product-catalog/view/cloud-computing-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Core Java (Advanced Level) (New)",
    url: "https://www.shl.com/products/product-catalog/view/core-java-advanced-level-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Customer Service Phone Simulation",
    url: "https://www.shl.com/products/product-catalog/view/customer-service-phone-simulation/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "B,S"
  },
  {
    name: "Data Science (New)",
    url: "https://www.shl.com/products/product-catalog/view/data-science-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Dependability and Safety Instrument (DSI)",
    url: "https://www.shl.com/products/product-catalog/view/dependability-and-safety-instrument-dsi/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "P"
  },
  {
    name: "Docker (New)",
    url: "https://www.shl.com/products/product-catalog/view/docker-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "English Comprehension (New)",
    url: "https://www.shl.com/products/product-catalog/view/english-comprehension-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Entry Level Sales Solution",
    url: "https://www.shl.com/products/product-catalog/view/entry-level-sales-solution/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "C,P"
  },
  {
    name: "Financial Accounting (New)",
    url: "https://www.shl.com/products/product-catalog/view/financial-accounting-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Front Office Management (New)",
    url: "https://www.shl.com/products/product-catalog/view/front-office-management-new/,Yes,No,K",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Global Skills Assessment",
    url: "https://www.shl.com/products/product-catalog/view/global-skills-assessment/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "C,K"
  },
  {
    name: "HTML5 (New)",
    url: "https://www.shl.com/products/product-catalog/view/html5-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Human Resources (New)",
    url: "https://www.shl.com/products/product-catalog/view/human-resources-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Java 8 (New)",
    url: "https://www.shl.com/products/product-catalog/view/java-8-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "JavaScript (New)",
    url: "https://www.shl.com/products/product-catalog/view/javascript-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Linux Administration (New)",
    url: "https://www.shl.com/products/product-catalog/view/linux-administration-new/,Yes,No,K",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Management Scenarios",
    url: "https://www.shl.com/products/product-catalog/view/management-scenarios/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "B"
  },
  {
    name: "Marketing (New)",
    url: "https://www.shl.com/products/product-catalog/view/marketing-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Mechanical Engineering (New)",
    url: "https://www.shl.com/products/product-catalog/view/mechanical-engineering-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Microsoft Excel 365 (New)",
    url: "https://www.shl.com/products/product-catalog/view/microsoft-excel-365-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K,S"
  },
  {
    name: "Motivation Questionnaire MQM5",
    url: "https://www.shl.com/products/product-catalog/view/motivation-questionnaire-mqm5/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "P"
  },
  {
    name: "Node.js (New)",
    url: "https://www.shl.com/products/product-catalog/view/node-js-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Occupational Personality Questionnaire OPQ32r",
    url: "https://www.shl.com/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "P"
  },
  {
    name: "Python Programming (New)",
    url: "https://www.shl.com/products/product-catalog/view/python-programming-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "ReactJS (New)",
    url: "https://www.shl.com/products/product-catalog/view/reactjs-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Sales Scenarios",
    url: "https://www.shl.com/products/product-catalog/view/sales-scenarios/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "B"
  },
  {
    name: "SQL Server (New)",
    url: "https://www.shl.com/products/product-catalog/view/sql-server-new/",
    remote_support: "Yes",
    adaptive_support: "No",
    test_type: "K"
  },
  {
    name: "Verbal Reasoning (New)",
    url: "https://www.shl.com/products/product-catalog/view/verbal-reasoning-new/",
    remote_support: "Yes",
    adaptive_support: "Yes",
    test_type: "A"
  },
  {
    name: "Numerical Reasoning (New)",
    url: "https://www.shl.com/products/product-catalog/view/numerical-reasoning-new/",
    remote_support: "Yes",
    adaptive_support: "Yes",
    test_type: "A"
  },
  {
    name: "Inductive Reasoning (New)",
    url: "https://www.shl.com/products/product-catalog/view/inductive-reasoning-new/",
    remote_support: "Yes",
    adaptive_support: "Yes",
    test_type: "A"
  }
];
