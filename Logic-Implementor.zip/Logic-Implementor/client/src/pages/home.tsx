import { useState } from "react";
import { getRecommendations, RecommendationResponse } from "@/lib/mock-api";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Loader2 } from "lucide-react";

export default function Home() {
  const [query, setQuery] = useState("");
  const [data, setData] = useState<RecommendationResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError("");
    setData(null);
    try {
      const result = await getRecommendations(query);
      setData(result);
    } catch (err) {
      setError("Failed to fetch recommendations. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b bg-white">
        <div className="container mx-auto px-4 h-16 flex items-center">
          <span className="font-serif font-bold text-xl text-primary">SHL Recommender</span>
        </div>
      </header>

      <main className="container mx-auto px-4 py-16 max-w-4xl">
        <section className="text-center mb-12">
          <h1 className="text-4xl font-serif font-bold mb-4 text-slate-900">
            Find the Right SHL Assessments
          </h1>
          <p className="text-lg text-slate-600">
            Describe your role requirements and get AI-powered assessment recommendations
          </p>
        </section>

        <form onSubmit={handleSearch} className="mb-12 space-y-4">
          <Textarea
            placeholder="e.g., Senior Java Developer who can lead a team and work with external stakeholders..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="min-h-24 text-base p-4"
          />
          <Button
            type="submit"
            disabled={loading || !query.trim()}
            size="lg"
            className="w-full"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Search className="mr-2 h-4 w-4" />
                Find Assessments
              </>
            )}
          </Button>
        </form>

        {error && (
          <Card className="mb-8 border-red-200 bg-red-50">
            <CardContent className="pt-6 text-red-800">{error}</CardContent>
          </Card>
        )}

        {data && (
          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="font-semibold text-sm text-slate-500 mb-1">Your Query</div>
                  <div className="text-slate-900">{data.query}</div>
                </div>
                <div>
                  <div className="font-semibold text-sm text-slate-500 mb-1">Rewritten for Search</div>
                  <div className="text-slate-900">{data.rewritten_query}</div>
                </div>
                <div>
                  <div className="font-semibold text-sm text-slate-500 mb-1">Reasoning</div>
                  <div className="text-slate-700 whitespace-pre-line">{data.explanation}</div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recommended Assessments ({data.recommended_assessments.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.recommended_assessments.map((assessment, idx) => (
                    <div key={idx} className="border-b pb-4 last:border-b-0">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-semibold text-slate-900">{assessment.name}</h3>
                          <p className="text-sm text-slate-600">Type: {assessment.test_type}</p>
                        </div>
                        <a
                          href={assessment.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:underline text-sm font-medium"
                        >
                          View →
                        </a>
                      </div>
                      <div className="text-xs text-slate-500 space-y-1">
                        <div>Remote Support: {assessment.remote_support}</div>
                        <div>Adaptive: {assessment.adaptive_support}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 text-white border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">API Response (JSON)</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-xs overflow-auto max-h-64 bg-slate-950 p-3 rounded border border-slate-800">
                  {JSON.stringify(data, null, 2)}
                </pre>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
