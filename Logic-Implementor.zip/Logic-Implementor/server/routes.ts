import type { Express } from "express";
import { createServer, type Server } from "http";
import Papa from "papaparse";
import fs from "fs";
import path from "path";

// Define Assessment type
interface Assessment {
  name: string;
  url: string;
  remote_support: string;
  adaptive_support: string;
  test_type: string;
}

// Global assessments data
let assessments: Assessment[] = [];

// Load assessments from CSV
function loadAssessments() {
  try {
    const csvPath = path.join(process.cwd(), "attached_assets", "shl_individual_test_solutions_final_1766032107257.csv");
    const csvFile = fs.readFileSync(csvPath, "utf8");
    
    Papa.parse(csvFile, {
      header: true,
      skipEmptyLines: true,
      complete: (results: Papa.ParseResult<Assessment>) => {
        assessments = results.data;
        console.log(`Loaded ${assessments.length} assessments from CSV`);
      },
      error: (error: any) => {
        console.error("Error parsing CSV:", error);
      }
    });
  } catch (error) {
    console.error("Error loading CSV file:", error);
    // Fallback data if file read fails
    assessments = [
      { name: "Java 8 (New)", url: "https://shl.com/java", remote_support: "Yes", adaptive_support: "No", test_type: "K" },
      { name: "Python Programming", url: "https://shl.com/python", remote_support: "Yes", adaptive_support: "No", test_type: "K" }
    ];
  }
}

// Initial load
loadAssessments();

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Health Check Endpoint
  app.get("/health", (req, res) => {
    res.json({ status: "healthy" });
  });

  // Assessment Recommendation Endpoint
  app.post("/recommend", (req, res) => {
    const { query } = req.body;
    
    if (!query) {
      return res.status(400).json({ error: "Query is required" });
    }

    const lowercaseQuery = query.toLowerCase();

    // 1. Rewrite Logic (Simple Mock)
    let rewritten = query;
    let intent = "General Hiring";
    
    if (lowercaseQuery.includes("java")) {
      rewritten = "Java, Software Development, Backend";
      intent = "Technical Hiring";
    } else if (lowercaseQuery.includes("sales")) {
      rewritten = "Sales, Negotiation, Communication";
      intent = "Sales Hiring";
    } else if (lowercaseQuery.includes("manager") || lowercaseQuery.includes("lead")) {
      rewritten = "Management, Leadership, Strategy";
      intent = "Leadership Hiring";
    } else if (lowercaseQuery.includes("analyst")) {
      rewritten = "Data Analysis, Excel, Critical Thinking";
      intent = "Analytical Hiring";
    }

    // 2. Scoring Logic
    const scored = assessments.map((item) => {
      let score = 0;
      const itemText = (item.name + " " + item.test_type).toLowerCase();
      
      // Keyword matching
      const queryTerms = lowercaseQuery.split(/\s+/);
      queryTerms.forEach((term: string) => {
        if (term.length > 2 && itemText.includes(term)) score += 3;
      });

      // Semantic categories
      if (lowercaseQuery.includes("developer") || lowercaseQuery.includes("code")) {
        if (item.test_type.includes("K") || item.test_type.includes("S")) score += 2;
      }
      if (lowercaseQuery.includes("manager") || lowercaseQuery.includes("lead")) {
        if (item.test_type.includes("B") || item.test_type.includes("P")) score += 2;
      }
      if (lowercaseQuery.includes("personality") || lowercaseQuery.includes("culture")) {
        if (item.test_type.includes("P")) score += 4;
      }
      if (lowercaseQuery.includes("aptitude") || lowercaseQuery.includes("cognitive")) {
        if (item.test_type.includes("A")) score += 4;
      }

      // Specific Boosts
      if (lowercaseQuery.includes("java") && item.name.toLowerCase().includes("java")) score += 10;
      if (lowercaseQuery.includes("python") && item.name.toLowerCase().includes("python")) score += 10;
      if (lowercaseQuery.includes("sales") && item.name.toLowerCase().includes("sales")) score += 10;
      if (lowercaseQuery.includes("excel") && item.name.toLowerCase().includes("excel")) score += 10;

      return { ...item, score };
    });

    // Sort by score
    scored.sort((a, b) => b.score - a.score);

    // Filter top results (min 1, max 10)
    let results = scored.filter(i => i.score > 0).slice(0, 8);
    
    // Fallback if no matches
    if (results.length === 0) {
      // Map fallback data to match the expected structure (with score) for consistent typing, even though score is 0
      results = assessments.slice(0, 5).map(a => ({ ...a, score: 0 }));
    }

    // Remove score from output
    const finalResults = results.map(({ score, ...rest }) => rest as Assessment);

    // 3. Explanation
    const explanation = `Based on your request "${query}", we identified key requirements for ${intent}. 
    
We recommended a balanced mix of assessments:
- Technical/Skill tests (Type K/S) to verify core competencies.
- Behavioral/Personality tests (Type P/B) to ensure cultural fit.

Top recommendation: ${finalResults[0]?.name || "General Assessment"}`;

    res.json({
      query,
      rewritten_query: rewritten,
      recommended_assessments: finalResults,
      explanation
    });
  });

  // Proxy API requests from frontend if needed, but here we serve directly
  // The frontend will call /recommend directly since it's same origin

  return httpServer;
}
